import ihmgui.*;
import iut.algo.*;
import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.awt.*;

public class Jeu extends Controle
{
	private   Labyrinthe  metier;     	// Classe Métier
	private   FrameGrille frame;        // Classe Vue
	private   boolean     closeGame;
	private   int         player;
	private   int         actions;

	private   int         lvlMax;
	private   String      lvlFile       = "datas/niveaux.txt";
	private   String      jrFile        = "datas/j";

	private   String      theme         = "default";
	private   String      saveFile      = "datas/save.txt";
	private   String      saveSeparator = ";;;";
	private   String      saveEnd       = "end";

	private   String      lsaveFile     = "datas/lastGame.txt";

	private   boolean     close=false;

	private int niveau = 1;
	private Chrono chrono = new Chrono();

	public Jeu(int niveau, int player)
	{
		this.player = player;
		this.lvlMax = Integer.valueOf(Save.getLineOfFile(this.player, this.lvlFile));
		this.niveau = lvlMax;

		init(this.niveau);
	}

	public void init(int niveau)
	{
		this.actions = 0;
		this.closeGame = false;

		metier = new Labyrinthe(niveau);				// instanciation de votre classe métier
		frame  = new FrameGrille ( this );  	// instanciation de la fenêtre graphique

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int) screenSize.getWidth();
		int height = (int) screenSize.getHeight();

		frame.setSize     ( (700), (360));
		frame.setLocation     ( (width-700)/2, (height-360)/2);
		frame.setTitle    ( "Labyrinthe"           );
		frame.setVisible  ( true                );

		chrono.start();

		Save.emptyFile(this.saveFile);
		saveGame();

		this.loadLastGame();

	}

	/* Méthode déclenchée par les touches de l'IHM          */
	public void jouer (String touche)
	{
		boolean played = false;

		if ( this.closeGame ) {
			frame.fermer();
			this.niveau++;
			init(this.niveau);
		} else if( touche.equals( "Q" ) ) {
			frame.fermer();
		}

		if ( touche.equals ( "FL-H" ) ) played = metier.deplacer ( 'N' );
		if ( touche.equals ( "FL-G" ) ){

			if (metier.victoire() && !this.closeGame)
			{
				Save.editLineInFile(this.lsaveFile, this.player, "0");

				if(this.niveau+1 > this.lvlMax)
				{
					Save.editLineInFile(this.lvlFile, this.player, String.valueOf(this.niveau+1));
					this.lvlMax++;
				}

				String bestScoreForLevel = Save.getLineOfFile(this.niveau, jrFile+String.valueOf(this.player)+".txt");
				String[] split = bestScoreForLevel.split(";;;");
				int bestActions = Integer.valueOf(split[0]);

				if(bestActions == 0 || bestActions >= actions )
				{
					// Nouveau meilleur score
					Save.editLineInFile(jrFile+String.valueOf(this.player)+".txt", this.niveau, String.valueOf(actions)+";;;"+chrono.tempsEnHMS());
				}

				this.closeGame = true;

				SoundEffect.FIN.play();
				this.jouer("NEXT");
			} else {
				played = metier.deplacer ( 'O' );
			}

		}
		if ( touche.equals ( "FL-B" ) ) played = metier.deplacer ( 'S' );
		if ( touche.equals ( "FL-D" ) ) played = metier.deplacer ( 'E' );

		if ( touche.equals("CR-Z") ) {
			this.loadLastAction();
		}

		if(played) {
			this.actions++;
			this.saveGame();
		}

		frame.majIHM();
	}

	public void loadLastAction()
	{
		if(Save.deleteFirstLineToFile(this.saveFile, this.saveSeparator, this.saveEnd))
		{
			String content =Save.getLineOfFile(this.player, this.lsaveFile);
			String[] result = content.split(this.saveSeparator+this.saveEnd);

			metier.loadMap(stringToStringArray(content), new int[] {getParam(result[0], 0), getParam(result[0], 1)}, new int[] {getParam(result[0], 2), getParam(result[0], 3)});
		}
	}

	public void loadLastGame()
	{
		if(!Save.getLineOfFile(this.player, this.lsaveFile).equals("0"))
		{
			String content = Save.readFile(this.lsaveFile);
			String[] result = content.split(this.saveSeparator);

			content = content.substring(4);

			if(Integer.valueOf(result[0]) == this.niveau) {
				metier.loadMap(stringToStringArray(content), new int[] {Integer.valueOf(result[1]), Integer.valueOf(result[2])}, new int[] {Integer.valueOf(result[1]), Integer.valueOf(result[1])});
			}
		}
	}

	public void saveGame()
	{
		String game = metier.serializeGame(this.saveSeparator, this.saveEnd);
		Save.addLineToFile(game, this.saveFile);
	}

	public int getParam(String strGame, int prm)
	{
		String[] exploded = strGame.split(this.saveSeparator);
		return Integer.valueOf(exploded[prm]);
	}

	public String[][] stringToStringArray(String strGame) // Convertir le résultat de serializeGame() (strGame) en tableau avec les cases
	{
		String[][] array = new String[3][3];

		String[] exploded = strGame.split(this.saveSeparator);
		String[] exploded2 = exploded[4].split("], ");

		array[0] = new String[] {exploded2[0].charAt(3)+""+exploded2[0].charAt(4), exploded2[0].charAt(9)+""+exploded2[0].charAt(10), exploded2[0].charAt(15)+""+exploded2[0].charAt(16)};
		array[1] = new String[] {exploded2[1].charAt(2)+""+exploded2[1].charAt(3), exploded2[1].charAt(8)+""+exploded2[1].charAt(9), exploded2[1].charAt(14)+""+exploded2[1].charAt(15)};
		array[2] = new String[] {exploded2[2].charAt(2)+""+exploded2[2].charAt(3), exploded2[2].charAt(8)+""+exploded2[2].charAt(9), exploded2[2].charAt(14)+""+exploded2[2].charAt(15)};

		return array;
	}

	public void glisser (int ligne1, int colonne1, int ligne2, int colonne2)
	{
		boolean played = false;

		if((metier.getCase(metier.getCharacter()[1], metier.getCharacter()[0]).getCrochet())) {
			if ( ligne1 > ligne2 && colonne1 == colonne2) played=metier.deplacerCase ( 'S' );
			if ( ligne1 == ligne2 && colonne1 > colonne2) played=metier.deplacerCase ( 'E' );
			if ( ligne1 == ligne2 && colonne1 < colonne2) played=metier.deplacerCase ( 'O' );
			if ( ligne1 < ligne2 && colonne1 == colonne2) played=metier.deplacerCase ( 'N' );

			frame.majIHM();
		}

		if(played) {
			this.actions++;
			saveGame();
		}

	}

	public void switchTheme()
	{
		if(this.theme == "default")
		{
			this.theme = "noel";
		} else {
			this.theme = "default";
		}
		frame.majIHM();
	}


	/* Méthode utilisée par l'IHM (paintComponnent)         */

	public String setImage ( int ligne, int colonne, int couche)
	{
		String img;;
		String rep = "./assets/images/";
		String sImage=null;

		img = metier.getCase(ligne, colonne).getImage();

		if (couche==0)
		{

			sImage = rep + theme + "/" + img;

		}
		else if(couche == 1)
		{
			if(ligne == metier.getCharacter()[1] && colonne == metier.getCharacter()[0])
			{
				sImage = rep + "aventurier_" + metier.getPion() +".gif";
			}
		}



		return sImage;
	}

	public void bouton  (int action)
	{
		if ( action == 0 ) {
			Save.editLineInFile(this.lsaveFile, this.player, "0");
			frame.fermer();
			init(niveau);
		}
		if ( action == 1 ) { this.close = true; }
		if ( action == 2 ) { previousLvl();        }
		if ( action == 3 ) { nextLvlBouton(); }
		if ( action == 4 ) { SelectLvl(); }
		if ( action == 5 ) { switchTheme(); }
		if ( action == 6 ) {
			Save.editLineInFile(this.lsaveFile, this.player, this.niveau+";;;"+metier.serializeGame(this.saveSeparator, this.saveEnd));
			this.closeGame = true;
		}
	}

	public void previousLvl()
	{
		if(niveau > 1) {
			niveau--;
			frame.fermer();
			init(niveau);
		}
	}

	public void nextLvlBouton()
	{
		if(niveau < lvlMax) {
			niveau++;
			frame.fermer();
			init(niveau);
		}
	}

	public String setBouton(int numBtn)
	{
		String lib;

		switch ( numBtn )
		{
			case 0 : lib = "Recommencer";            break;
			case 1 : lib = "Menu Principale";        break;
			case 2 : lib = "Descendre de niveau";      break;
			case 3 : lib = "Monter de niveau";      break;
			case 4 : lib = "Choisir le niveau";      break;
			case 5 : lib = "Switch theme";      break;
			case 6 : lib = "Quitter";      break;
			default: lib = null;
		}

		return lib;
	}

	public void SelectLvl()
	{
		System.out.print("Niveau: ");
		int newNiveau = Clavier.lire_int();
		if (newNiveau >= 1 && newNiveau <= this.lvlMax) //newNiveau < this.niveau
		{
			this.niveau = newNiveau;
			frame.fermer();
			this.init(niveau);
		}
		else
		{
			System.out.println("ERREUR");
		}
	}

	public void reset()
	{
		frame.fermer();
		init(this.niveau);
	}

	public String  setTextLabel      (int numLbl)
	{

		String bestScoreForLevel = Save.getLineOfFile(this.niveau, jrFile+String.valueOf(this.player)+".txt");
		String[] split = bestScoreForLevel.split(";;;");
		int bestActions = Integer.valueOf(split[0]);
		String bestTime = split[1];
		switch(numLbl)
		{
			case 0:
			return chrono.tempsEnHMS();
			case 1:
			return String.valueOf(bestActions);
			case 2:
			return bestTime;
		}

		return "";
	}

	public String setLabel (int numLbl)
	{
		String lib;
		switch ( numLbl )
		{
			case 0 : lib = "Temps: ";       break;
			case 1 : lib = "B Actions: ";   break;
			case 2 : lib = "B Temps  : ";	break;
			default: lib = null;                    // cette dernière ligne est importante, elle met fin à la contruction des labels
		}

		return lib;
	}

	public boolean get(String var)
	{
		frame.majIHM();

		switch(var)
		{
			case "close":
			return this.closeGame;
			case "menu":
			return this.close;
			default:
			return false;
		}
	}

	public void sleep(int ms)
	{
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread().interrupt();
		}
	}

	public void    fermer()
	{
		this.frame.fermer();
	}

	public int     setMargeBtnLabel  () { return 0;                                   }
	public int     setLargeurLabel   () { return 150;                                  }
	public int     setNbLigne        () { return metier.getNbLigne();                  }
	public int     setNbColonne      () { return metier.getNbColonne();                }
	public boolean setNumLigneColonne() { return false;                                }
	public boolean setCoordonneesInfo() { return false;                                }
	public int     setLargeurImg     () { return 80;                                   }
	public String  setFondGrille     () { return "assets/images/"+theme+"/plateau.gif";          }
	public int  setDeltaX            () { return -34;                 				   }
	public int  setDeltaY            () { return -37;                 				   }

}
