import java.util.Calendar;

public class Chrono
{

	private long depart, pause, time;

	public void start(){this.depart = System.currentTimeMillis();}

	public String tempsEnHMS(){

		this.pause =  System.currentTimeMillis();
		int h, m , s;
		long time ;
		String c ;
		time = this.pause - this.depart ;
		h = (int)(time / (long)(3.6*10000000)) ;
		m =(int)((time % (long)(3.6*10000000)) /  60000) ;
		s= (int)(((time % (long)(3.6*10000000)) %  60000)/ 1000) ;
		c = h + " h " + m +" m " + s + " s" ;
		return c ;
	}

	public String timeTotal(){

		int h, m , s;
		long time ;
		String c ;
		time = this.pause - this.depart ;
		h = (int)(time / (long)(3.6*10000000)) ;
		m =(int)((time % (long)(3.6*10000000)) /  60000) ;
		s= (int)(((time % (long)(3.6*10000000)) %  60000)/ 1000) ;
		c =  h + " h " + m +" m " + s + " s" ;
		return c ;
	}

	public void reset(){this.depart =System.currentTimeMillis();}
}
