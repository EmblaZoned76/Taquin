import ihmgui.*       ;
import iut.algo.*     ;
import java.util.*    ;
import java.io.*      ;
import java.nio.file.*;

public class Config
{
	public static String[][] tilesDatas()
	{
		// Format: Identifiant tuile ; Somme mur de la tuile ; Image de la tuile ; Crochet sur la tuile ; Etage tuile ; Escalier tuile
		String[][] content = new String[][] {
			{"+1", "10", "pPlus1.gif",   "non", "2", " "},
			{"+2",  "5", "pPlus2.gif",   "non", "2", " "},
			{"+3", "10", "pPlus1.gif",   "non", "2", " "},
			{"+4",  "5", "pPlus2.gif",   "non", "2", " "},
			{"O1",  "9", "pX1.gif",      "oui", "0", " "},
			{"O2",  "3", "pX2.gif",      "oui", "0", " "},
			{"O3",  "6", "pX3.gif",      "oui", "0", " "},
			{"O4", "12", "pX4.gif",      "oui", "0", " "},
			{"X1",  "9", "pX1.gif",      "oui", "0", " "},
			{"X2",  "3", "pX2.gif",      "oui", "0", " "},
			{"X3",  "6", "pX3.gif",      "oui", "0", " "},
			{"X4", "12", "pX4.gif",      "oui", "0", " "},
			{"T1",  "9", "pX1.gif",      "oui", "0", " "},
			{"T2",  "3", "pX2.gif",      "oui", "0", " "},
			{"T3",  "6", "pX3.gif",      "oui", "0", " "},
			{"T4", "12", "pX4.gif",      "oui", "0", " "},
			{"=1",  "9", "pCarre1.gif",  "non", "2", " "},
			{"=2",  "3", "pCarre2.gif",  "non", "2", " "},
			{"=3",  "6", "pCarre3.gif",  "non", "2", " "},
			{"=4", "12", "pCarre4.gif",  "non", "2", " "},
			{"C1",  "9", "pCarre1.gif",  "non", "2", " "},
			{"C2",  "3", "pCarre2.gif",  "non", "2", " "},
			{"C3",  "6", "pCarre3.gif",  "non", "2", " "},
			{"C4", "12", "pCarre4.gif",  "non", "2", " "},
			{"L1", "10", "pEtoile1.gif", "oui", "1", "N"},
			{"L2",  "5", "pEtoile2.gif", "oui", "1", "E"},
			{"L3", "10", "pEtoile3.gif", "oui", "1", "S"},
			{"L4",  "5", "pEtoile4.gif", "oui", "1", "O"},
			{"E1", "10", "pEtoile1.gif", "oui", "1", "N"},
			{"E2",  "5", "pEtoile2.gif", "oui", "1", "E"},
			{"E3", "10", "pEtoile3.gif", "oui", "1", "S"},
			{"E4",  "5", "pEtoile4.gif", "oui", "1", "O"}
		};
		return content;
	}

	public static boolean nConds(int y, int x, Case[][] tab)
	{
		String[][][] conds = new String[][][] {
			{
				{"0", "0", "etage", "0"},
				{"-1", "0", "escalier", "N"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "S"},
				{"-1", "0", "etage", "0"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "N"},
				{"-1", "0", "etage", "2"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "S"},
				{"-1", "0", "etage", "1"},
				{"-1", "0", "escalier", "N"}
			},
			{
				{"0", "0", "etage", "2"},
				{"-1", "0", "escalier", "S"}
			}
		};

		return allCondsValid(conds, y, x, tab);
	}

	public static boolean oConds(int y, int x, Case[][] tab)
	{
		String[][][] conds = new String[][][] {
			{
				{"0", "0", "etage", "0"},
				{"0", "-1", "escalier", "O"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "E"},
				{"0", "-1", "etage", "0"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "O"},
				{"0", "-1", "etage", "2"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "O"},
				{"0", "-1", "etage", "1"},
				{"0", "-1", "escalier", "E"}
			},
			{
				{"0", "0", "etage", "2"},
				{"0", "-1", "escalier", "E"}
			}
		};

		return allCondsValid(conds, y, x, tab);
	}

	public static boolean sConds(int y, int x, Case[][] tab)
	{
		String[][][] conds = new String[][][] {
			{
				{"0", "0", "etage", "0"},
				{"1", "0", "escalier", "S"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "S"},
				{"1", "0", "etage", "2"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "N"},
				{"1", "0", "etage", "0"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "N"},
				{"1", "0", "etage", "1"},
				{"1", "0", "escalier", "S"}
			},
			{
				{"0", "0", "etage", "2"},
				{"1", "0", "escalier", "N"}
			}
		};

		return allCondsValid(conds, y, x, tab);
	}

	public static boolean eConds(int y, int x, Case[][] tab)
	{
		String[][][] conds = new String[][][] {
			{
				{"0", "0", "etage", "0"},
				{"0", "1", "escalier", "E"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "O"},
				{"0", "1", "etage", "0"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "E"},
				{"0", "1", "etage", "2"}
			},
			{
				{"0", "0", "etage", "1"},
				{"0", "0", "escalier", "E"},
				{"0", "1", "etage", "1"},
				{"0", "1", "escalier", "O"}
			},
			{
				{"0", "0", "etage", "2"},
				{"0", "1", "escalier", "O"}
			}
		};

		return allCondsValid(conds, y, x, tab);
	}

	public static boolean allCondsValid(String[][][] conds, int y, int x, Case[][] tab)
	{
		boolean valid = true;

		for(int i=0;i<conds.length;i++)
		{
			valid = true;
			for(int j=0;j<conds[i].length;j++)
			{
				if(conds[i][j][2] == "etage")
				{
					if(tab[y+Integer.valueOf(conds[i][j][0])][x+Integer.valueOf(conds[i][j][1])].getEtage() != Integer.valueOf(conds[i][j][3])) {
						valid = false;
					}
				}
				else
				{
					if(tab[y+Integer.valueOf(conds[i][j][0])][x+Integer.valueOf(conds[i][j][1])].getEscalier() != conds[i][j][3].charAt(0))
					{
						valid = false;
					}
				}
			}

			if(valid)
			{
				break;
			}
		}

		return valid;
	}
}
