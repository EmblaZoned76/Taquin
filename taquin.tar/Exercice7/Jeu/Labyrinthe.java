/** Exercice 7
* date        : Le 16/12/2019
* @author : Paon Louis , Atinault Maximilien , Evain Philippe , Tristan Martin , Bouquet Antoine
* @ version : 1
*/
import iut.algo.*;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.*;

public class Labyrinthe
{

	//********************************//
	//            Attributs           //
	//                                //
	//********************************//

	private Case[][]      tab      ;
	private int           posX     ;
	private int           posY     ;
	private int           videX    ;
	private int           videY    ;
	private int           lignes   ;
	private int           colonnes ;
	private char          pion      = 'S';
	private String[][]    tabCases;
	Map<String, String[]> ptsImages = new HashMap<>();

	//********************************//
	//          Constructeur          //
	//                                //
	//********************************//
	public Labyrinthe(int level)
	{
		this.initPtsImages();

		// Positionnement par défaut
		this.posX = colonnes-1;
		this.posY = lignes  -1;

		int[][] points = calcPointsLevel(level);

		//Initialisation des lignes et des colonnes
		this.lignes   = 3;
		this.colonnes = 3;

		//Initialisation du tableau et positionnement du joueur
		this.tab = new Case[lignes][colonnes];

		//Remplissage du tableau
		for (int lig=0; lig<lignes; lig++)
		{
			for (int col=0; col<colonnes; col++)
			{
				if(ptsImages.containsKey(tabCases[lig][col]))
				{
					this.tab[lig][col] = new Case(tabCases[lig][col], Integer.valueOf(ptsImages.get(tabCases[lig][col])[0]), this.ptsImages.get(tabCases[lig][col])[1], this.ptsImages.get(tabCases[lig][col])[2], Integer.valueOf(this.ptsImages.get(tabCases[lig][col])[3]), this.ptsImages.get(tabCases[lig][col])[4].charAt(0));
				}
				else
				{
					this.tab[lig][col] = new Case(tabCases[lig][col]);
				}
			}
		}
	}

	//********************************//
	//         Initialisation         //
	//           des tuiles           //
	//********************************//
	public void initPtsImages()
	{
		String[][] datas = Config.tilesDatas();

		for(int i=0;i<datas.length;i++)
		{
			this.ptsImages.put(datas[i][0], new String[] {datas[i][1], datas[i][2], datas[i][3], datas[i][4], datas[i][5]});
		}
	}

	//********************************//
	//           Déplacement          //
	//            du joueur           //
	//********************************//
	public boolean deplacer(char dir )
	{
		dir = Character.toUpperCase(dir);

		switch (dir)
		{
			case 'N':
			{
				this.pion = 'N';
				return this.deplacerAuNord(this.posX, this.posY, this.tab);
			}
			case 'O':
			{
				this.pion = 'O';
				return deplacerAOuest(this.posX, this.posY, this.tab);
			}
			case 'S':
			{
				this.pion = 'S';
				return this.deplacerAuSud(this.posX, this.posY, this.tab);
			}
			case 'E':
			{
				this.pion = 'E';
				return this.deplacerAEst(this.posX, this.posY, this.tab);
			}
		}

		return false;
	}

	//********************************//
	//           Déplacement          //
	//            des cases           //
	//********************************//
	public boolean deplacerCase(char dir )
	{
		Case tmp;
		dir = Character.toUpperCase(dir);

		switch (dir)
		{
			case 'N':
			{
				if(this.videY > 0 && !(getCharacter()[0] == videX && getCharacter()[1] == videY-1))
				{
					tmp = this.tab[this.videY-1][this.videX];
					this.tab[this.videY-1][this.videX] = new Case("  ");
					this.tab[this.videY][this.videX]   = tmp;
					this.videY--;
					SoundEffect.MOVECASE.play();
					return true;
				}
				break;
			}
			case 'O':
			{
				if(this.videX > 0 && !(getCharacter()[0] == videX-1 && getCharacter()[1] == videY))
				{
					tmp = this.tab[this.videY][this.videX-1];
					this.tab[this.videY][this.videX-1] = new Case("  ");
					this.tab[this.videY][this.videX]   = tmp;
					this.videX--;
					SoundEffect.MOVECASE.play();
					return true;
				}
				break;
			}
			case 'S':
			{
				if(this.videY+1 < this.lignes && !(getCharacter()[0] == videX && getCharacter()[1] == videY+1))
				{
					tmp = this.tab[this.videY+1][this.videX];
					this.tab[this.videY+1][this.videX] = new Case("  ");
					this.tab[this.videY][this.videX]   = tmp;
					this.videY++;
					SoundEffect.MOVECASE.play();
					return true;
				}
				break;
			}
			case 'E':
			{
				if(this.videX+1 < this.colonnes && !(getCharacter()[0] == videX+1 && getCharacter()[1] == videY))
				{
					tmp = this.tab[this.videY][this.videX+1];
					this.tab[this.videY][this.videX+1] = new Case("  ");
					this.tab[this.videY][this.videX]   = tmp;
					this.videX++;
					SoundEffect.MOVECASE.play();
					return true;
				}
				break;
			}
			default :
			break;
		}

		return false;
	}

	//********************************//
	//       Récupérer la somme       //
	//          des murs (TXT)        //
	//********************************//
	public int[][] calcPointsLevel(int level){
		String rep = "assets/niveaux/niveau";

		try{
			Scanner sc = new Scanner ( new File(rep+String.format("%02d", level)+".txt") );
			int lig = -1;
			int cpt = -1;
			int col = 0;
			String line = "";

			while (!(line = sc.nextLine()).isEmpty())
			{
				lig++;
				col = line.length();
			}

			char[][] tab = new char[lig][col];

			sc = new Scanner( new File(rep+String.format("%02d", level)+".txt"));
			while(!(line = sc.nextLine()).isEmpty())
			{
				if(cpt > 0) { tab[cpt] = line.toCharArray(); }
				cpt++;
			}
			sc.close();

			int[][] point = new int[lig/2][col/6];
			tabCases = new String[lig/2][col/6];

			for(int i=1;i<lig;i+=2)
			{
				for(int j=2;j<col;j+=6)
				{
					tabCases[i/2][j/6] = tab[i][j]+""+tab[i][j+1];

					if(ptsImages.containsKey(tab[i][j]+""+tab[i][j+1]))
					{
						point[i/2][j/6] =  Integer.valueOf(ptsImages.get(tab[i][j]+""+tab[i][j+1])[0]);
					}

					if((tab[i][j]+""+tab[i][j+1]).equals("  "))
					{
						this.videX = j/6;
						this.videY = i/2;
					}

					if(tab[i][j+2] == 'P' || tab[i][j+2] == 'p')
					{
						this.posY = i/2;
						this.posX = j/6;
					}

				}
			}

			return point;
		}
		catch (FileNotFoundException e){
			return new int[3][3];
		}
	}

	//********************************//
	//      Vérifier la victoire      //
	//                                //
	//********************************//
	public boolean victoire()
	{

		return this.posX == 0 && this.posY == 0 &&
		((this.getCase(this.posX, this.posY).getSymbole().equals("+2")
		|| this.getCase(this.posX, this.posY).getSymbole().equals("+4")
		|| this.getCase(this.posX, this.posY).getSymbole().equals("=2")
		|| this.getCase(this.posX, this.posY).getSymbole().equals("C2"))
		|| (this.getCase(this.posX, this.posY).getEtage() == 1
		&& this.getCase(this.posX, this.posY).getEscalier() == 'O'));
	}

	//********************************//
	//       Récupérer la somme       //
	//          des murs (STR)        //
	//********************************//
	public int[][] calcPointsGrille(String[][] grille)
	{
		int[][] point = new int[3][3];

		for(int x=0;x<3;x++)
		{
			for(int y=0;y<3;y++)
			{
				if(ptsImages.containsKey(grille[x][y]))
				{
					point[x][y] = Integer.valueOf(ptsImages.get(grille[x][y])[0]);
				}
			}
		}

		return point;
	}

	//********************************//
	//        Recharger une map       //
	//                                //
	//********************************//
	public void loadMap(String[][] cases, int[] characterPos, int[] videPos)
	{
		this.posX = characterPos[0];
		this.posY = characterPos[1];

		this.videX = videPos[0];
		this.videY = videPos[1];

		int[][] points = calcPointsGrille(cases);

		//Remplissage du tableau
		for (int lig=0; lig<3; lig++)
		{
			for (int col=0; col<3; col++)
			{
				if(ptsImages.containsKey(cases[lig][col]))
				{
					this.tab[lig][col] = new Case(cases[lig][col], Integer.valueOf(ptsImages.get(cases[lig][col])[0]), this.ptsImages.get(cases[lig][col])[1], this.ptsImages.get(cases[lig][col])[2], Integer.valueOf(this.ptsImages.get(cases[lig][col])[3]), this.ptsImages.get(cases[lig][col])[4].charAt(0));
				}
				else
				{
					this.tab[lig][col] = new Case(cases[lig][col]);
				}
			}
		}
	}

	//********************************//
	//      Transformation de la      //
	//        partie en Chaine        //
	//********************************//
	public String serializeGame(String separator, String end)
	{
		String message = "";
		message += getCharacter()[0]; // posX
		message += separator + getCharacter()[1]; // posY
		message += separator + getVide()[0]; // videX
		message += separator + getVide()[1]; // videY
		message += separator + Arrays.deepToString(getTab()); // tableau
		message += separator + end;

		return message;
	}

	//********************************//
	//           Accesseurs           //
	//                                //
	//********************************//
	public int      getNbLigne  ()               { return this.tab.length;                   }
	public int      getNbColonne()               { return this.tab[0].length;                }
	public Case     getCase(int lig, int col)    { return this.tab[lig][col];                }
	public String   getSymbole (int lig, int col){ return this.tab[lig][col].getSymbole() ;  }
	public int[]    getCharacter()               { return new int[] {this.posX, this.posY};  }
	public int[]    getVide()                    { return new int[] {this.videX, this.videY};}
	public char     getPion()                    { return this.pion;                         }
	public Case[][] getTab()                     { return this.tab;                          }


	//********************************//
	//     Déplacement du joueur      //
	//              NORD              //
	//********************************//
	public boolean deplacerAuNord(int posX, int posY, Case[][] tab)
	{
		if(this.posY > 0 && this.tab[this.posY-1][this.posX].getSommeMur()%8/4 == 0 && this.tab[this.posY][this.posX].getSommeMur()%8%4%2 == 0)
		{
			if( ((this.tab[this.posY-1][this.posX].getEtage() == this.tab[this.posY][this.posX].getEtage())  // Si on est sur le même étage
			&& !(this.tab[this.posY-1][this.posX].getEscalier() == 'N' // et si il n'y a pas d'escalier au nord de la case du nord et que l'on est sur une case avec un escalier au nord.
			&& this.tab[this.posY][this.posX].getEscalier() == 'N'))
			|| Config.nConds(this.posY, this.posX, this.tab) ) // Gestion des étages
			{
				this.posY--;
				SoundEffect.PAS.play();
				return true;
			}
			else
			{
				SoundEffect.MUR.play();
			}
		}
		else
		{
			SoundEffect.MUR.play();
		}

		return false;
	}

	//********************************//
	//     Déplacement du joueur      //
	//              SUD               //
	//********************************//
	public boolean deplacerAuSud(int posX, int posY, Case[][] tab)
	{
		if(this.posY+1 < this.lignes && this.tab[this.posY+1][this.posX].getSommeMur()%8%4%2 == 0 && this.tab[this.posY][this.posX].getSommeMur()%8/4 == 0)
		{
			if(((this.tab[this.posY+1][this.posX].getEtage() == this.tab[this.posY][this.posX].getEtage())
			&& !(this.tab[this.posY+1][this.posX].getEscalier() == 'S'
			&& this.tab[this.posY][this.posX].getEscalier() == 'S'))  // si on est sur le même étage
			|| Config.sConds(this.posY, this.posX, this.tab))
			{
				this.posY++;
				SoundEffect.PAS.play();
				return true;
			}
			else
			{
				SoundEffect.MUR.play();
			}
		}
		else
		{
			SoundEffect.MUR.play();
		}

		return false;
	}

	//********************************//
	//     Déplacement du joueur      //
	//              OUEST             //
	//********************************//
	public boolean deplacerAOuest(int posX, int posY, Case[][] tab)
	{
		if(this.posX > 0 && this.tab[this.posY][this.posX-1].getSommeMur()%8%4/2 == 0 && this.tab[this.posY][this.posX].getSommeMur()/8 == 0)
		{
			if(((this.tab[this.posY][this.posX-1].getEtage() == this.tab[this.posY][this.posX].getEtage())
			&& !(this.tab[this.posY][this.posX-1].getEscalier() == 'O'
			&& this.tab[this.posY][this.posX].getEscalier() == 'O'))
			|| Config.oConds(this.posY, this.posX, this.tab))
			{
				this.posX--;
				SoundEffect.PAS.play();
				return true;
			}
			else
			{
				SoundEffect.MUR.play();
			}
		}
		else
		{
			SoundEffect.MUR.play();
		}

		return false;
	}

	//********************************//
	//     Déplacement du joueur      //
	//              EST               //
	//********************************//
	public boolean deplacerAEst(int posX, int posY, Case[][] tab)
	{
		if(this.posX+1 < this.colonnes && this.tab[this.posY][this.posX+1].getSommeMur()/8 == 0 && this.tab[this.posY][this.posX].getSommeMur()%8%4/2 == 0)
		{
			if(((this.tab[this.posY][this.posX+1].getEtage() == this.tab[this.posY][this.posX].getEtage())
			&& !(this.tab[this.posY][this.posX+1].getEscalier() == 'E'
			&& this.tab[this.posY][this.posX].getEscalier() == 'E'))  // si on est sur le même étage
			|| Config.eConds(this.posY, this.posX, this.tab))
			{
				this.posX++;
				SoundEffect.PAS.play();
				return true;
			} else {
				SoundEffect.MUR.play();
			}
		}
		else
		{
			SoundEffect.MUR.play();
		}

		return false;
	}
}
