import ihmgui.*;
import iut.algo.*;
import java.util.*;
import java.io.*;
import java.nio.file.*;

public class Controleur extends Controle
{
	private Menu menu;
	private Jeu  jeu;
	private boolean menuOuvert;
	private boolean jeuOuvert;

	public void ouvrirMenu()
	{
		this.menu = new Menu();
		this.menuOuvert = true;
	}

	public void listen()
	{
		while(true) {
			if(this.menuOuvert)
			{
				if(this.menu.get("close"))
				{
					this.menu.fermer();
					this.menuOuvert = false;
				}
				else if(this.menu.get("play"))
				{
					int player = menu.getPlayer();
					this.menu.fermer();
					this.menuOuvert = false;
					this.jeuOuvert  = true;
					this.jeu = new Jeu(1, player);
				}
			}
			else if(this.jeuOuvert)
			{
				if(this.jeu.get("menu"))
				{
					this.jeu.fermer();
					this.jeuOuvert = false;
					this.ouvrirMenu();
				} else if(this.jeu.get("close"))
				{
					this.jeu.fermer();
					this.jeuOuvert = false;
					this.menuOuvert = false;
				}
			}
			else
			{
				break;
			}

			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
				Thread.currentThread().interrupt();
			}
		}
	}

	public static void main(String[] arg)
	{
		//SoundEffect.MUSIQUE.play();
		Controleur ctrl = new Controleur();
		ctrl.ouvrirMenu();
		ctrl.listen();
	}

}
