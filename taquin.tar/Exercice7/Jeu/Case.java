/**
* Case
* @author Equipe 6
* @version 1 du 17-12-2019
*/

public class Case
{
	/*------------------------*/
	/*         Donnees        */
	/*------------------------*/

	private String    symbole  ;
	private int       sommeMur ;
	private String    image    ;
	private boolean   crochet  ;
	private int       etage    ;
	private char      escalier ;

	/*------------------------*/
	/*      Constructeur      */
	/*------------------------*/

	public Case(String str, int mur, String img, String crochet, int etage, char escalier)
	{
		this.symbole  = str;
		this.sommeMur = mur;
		this.image    = img;
		if(crochet.equals("oui"))
		{
			this.crochet = true;
		}
		else
		{
			this.crochet = false;
		}
		this.etage    = etage   ;
		this.escalier = escalier;
	}

	public Case(String str)
	{
		this(str, 15, "vide80.gif", "non", 0, ' ');
	}

	/*------------------------*/
	/*   Méthode getSymbole() */
	/*------------------------*/

	public String getSymbole()
	{
		return this.symbole;
	}

	public int getSommeMur()
	{
		return this.sommeMur;
	}

	public String getImage()
	{
		return this.image;
	}

	public boolean getCrochet()
	{
		return this.crochet;
	}

	public int getEtage()
	{
		return this.etage;
	}

	public char getEscalier()
	{
		return this.escalier;
	}

	/*------------------------*/
	/*  Méthode toString()    */
	/*------------------------*/

	public String toString()
	{
		return "\"" + this.symbole + "\"";
	}
}
