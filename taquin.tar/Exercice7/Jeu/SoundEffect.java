import java.io.*            ;
import javax.sound.sampled.*;
import java.net.URL         ;

public enum SoundEffect
{
	FIN      ( "assets/sons/fin.wav" )    ,
	MUR      ( "assets/sons/mur.wav" )    ,
	PAS      ( "assets/sons/pas.wav" )    ,
	MOVECASE ( "assets/sons/case.wav" )   ,
	MUSIQUE  ( "assets/sons/musique.wav" );


	public static enum Volume{ MUTE, LOW, MEDIUM, HIGH }

	public static Volume volume = Volume.MEDIUM;
	private       Clip   clip                  ;

	SoundEffect( String source)
	{
		try
		{
			URL url = this.getClass().getClassLoader().getResource(source);
			AudioInputStream stream = AudioSystem.getAudioInputStream(url);
			clip = AudioSystem.getClip();
			clip.open (stream);
		}
		catch(Exception e)
		{}
		}

		public void play()
		{
			if ( clip.isRunning() )clip.stop();
			clip.setFramePosition(0);
			clip.start();
		}

		static void init()
		{
			values();
		}
	}
