import iut.algo.*      ;
import java.util.*     ;
import java.io.*       ;
import java.nio.file.* ;

public class Save
{

	public static void emptyFile(String filename)
	{
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			writer.write("");
			writer.close();
		} catch (Exception e) {

		}
	}

	public static String readFile(String filename)
	{
		String content = "";

		try {
			InputStream is = new FileInputStream(filename);
			BufferedReader buf = new BufferedReader(new InputStreamReader(is));

			String line = buf.readLine();
			StringBuilder sb = new StringBuilder();

			while(line != null){
				if(!line.trim().isEmpty())
				{
					sb.append(line).append(System.getProperty("line.separator"));
				}

				line = buf.readLine();

			}
			buf.close();

			content = sb.toString();
		} catch(Exception e) {
			//
		}

		return content+System.getProperty("line.separator");
	}

	public static void addLineToFile(String line, String filename)
	{
		String content = readFile(filename);

		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			writer.write(line+System.getProperty("line.separator")+content);
			writer.close();
		} catch (Exception e) {
			//
		}

	}

	public static boolean deleteFirstLineToFile(String filename, String separator, String end)
	{
		String moves = readFile(filename);
		String[] lines = moves.split(separator+end);

		if(lines.length > 2)
		{
			moves = moves.substring(moves.indexOf(separator+end)+separator.length()+end.length()+1);

			try
			{
				BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
				writer.write(moves);
				writer.close();

			}
			catch (Exception e)
			{
				System.out.println(e);
			}

			return true;
		}
		else
		{
			return false;
		}
	}

	public static String getLineOfFile(int line, String filename)
	{
		try {
			return Files.readAllLines(Paths.get(filename)).get(line-1);
		}
		catch(Exception e)
		{
			return "";
		}
	}

	public static void editLineInFile(String filename, int line, String content)
	{
		try
		{
			String fileContent = "";
			FileReader fr  = new FileReader( filename );
			Scanner sc     = new Scanner ( fr );

			int cpt = 0;
			while (sc.hasNextLine())
			{
				String lineContent = sc.nextLine();

				if(cpt+1 == line) {
					fileContent += content + System.getProperty("line.separator");
				} else {
					fileContent += lineContent + System.getProperty("line.separator");
				}

				cpt++;
			}

			sc.close();
			fr.close();

			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			writer.write(fileContent);
			writer.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
