import ihmgui.*       ;
import iut.algo.*     ;
import java.util.*    ;
import java.io.*      ;
import java.nio.file.*;
import java.awt.*     ;

public class Menu extends Controle
{
	private   FrameGrille frame          ;        // Classe Vue
	private   boolean     close   = false;
	private   boolean     play    = false;
	private   int         player  = 0    ;

	public Menu()
	{
		frame  = new FrameGrille ( this );  	// instanciation de la fenêtre graphique

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int width            = (int) screenSize.getWidth();
		int height           = (int) screenSize.getHeight();

		frame.setSize     ( (730), (515));
		frame.setLocation ( (width-730)/2, (height-515)/2);
		frame.setTitle    ( "Labyrinthe"                 );
		frame.setVisible  ( true                         );

	}

	public void jouer (String touche)
	{
		frame.majIHM();
	}

	/* Méthode utilisée par l'IHM (paintComponnent)         */

	public String setImage (int ligne, int colonne, int couche)
	{
		String img;
		String sImage = "";

		img = "test.gif";
		if (couche==0)
		{

			sImage = img;

		}


		return sImage;
	}

	public void cliquer(int x, int y)
	{
		this.close = x >= 31 && x <= 40 && y >= 41 && y <= 58;

		if(x >= 17 && x <= 26 && y >= 5 && y <= 22)
		{
			this.player = 1;
			this.play = true;
		}
		else if(x >= 17 && x <= 25 && y >= 41 && y <= 58)
		{
			this.player = 2;
		}
		else if(x >= 32 && x <= 40 && y >= 4 && y <= 22)
		{
			this.player = 3;
		}

		if(this.player != 0)
		{
			this.play = true;
		}
	}

	public int     setNbLigne        () { return 40;                          }
	public int     setNbColonne      () { return 63;                          }
	public boolean setNumLigneColonne() { return false;                       }
	public boolean setCoordonneesInfo() { return false;                       }
	public int     setLargeurImg     () { return 10;                          }
	public String  setFondGrille     () { return "assets/images/Ecran.gif";   }
	public int  setDeltaX            () { return -40;                         }
	public int  setDeltaY            () { return -40;                         }

	public boolean get(String var)
	{
		switch(var)
		{
			case "close":
			return this.close;
			case "play":
			return this.play;
			default:
			return false;
		}
	}

	public void    fermer()
	{
		this.frame.fermer();
	}

	public int getPlayer()
	{
		return this.player;
	}

	public static void main(String[] arg)
	{
		Menu exemple = new Menu();

	}

}
