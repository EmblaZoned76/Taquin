/** Un premier programme
* date     :
* @author  : Maximilien Atinault
* @version 1 du date
*/

// import iut.algo.Clavier;
import java.io.FileReader;
import iut.algo.Decomposeur;
import iut.algo.*;
import java.io.FileNotFoundException;
import java.io.File;
import java.util.*;

import java.io.PrintWriter;

public class affichageNiveauHtml
{
	public Map<String, String[]> ptsImages = new HashMap<>();

	public void initPtsImages()
	{
		this.ptsImages.put("+1", new String[] {"10", "pPlus1.gif", "non", "2", " "});
		this.ptsImages.put("+2", new String[] {"5", "pPlus2.gif", "non", "2", " " });
		this.ptsImages.put("+3", new String[] {"10", "pPlus1.gif", "non", "2", " "});
		this.ptsImages.put("+4", new String[] {"5", "pPlus2.gif", "non", "2", " " });

		char[] repeat1 = new char[] {'O', 'X', 'T'};
		for(int i=0;i<repeat1.length;i++)
		{
			this.ptsImages.put(repeat1[i] + "1", new String[] {"9", "pX1.gif", "oui", "0", " " });
			this.ptsImages.put(repeat1[i] + "2", new String[] {"3", "pX2.gif", "oui", "0", " " });
			this.ptsImages.put(repeat1[i] + "3", new String[] {"6", "pX3.gif", "oui", "0", " " });
			this.ptsImages.put(repeat1[i] + "4", new String[] {"12", "pX4.gif", "oui", "0", " "});
		}

		char[] repeat2 = new char[] {'=', 'C'};
		for(int i=0;i<repeat2.length;i++)
		{
			this.ptsImages.put(repeat2[i] + "1", new String[] {"9", "pCarre1.gif", "non", "2", " " });
			this.ptsImages.put(repeat2[i] + "2", new String[] {"3", "pCarre2.gif", "non", "2", " " });
			this.ptsImages.put(repeat2[i] + "3", new String[] {"6", "pCarre3.gif", "non", "2", " " });
			this.ptsImages.put(repeat2[i] + "4", new String[] {"12", "pCarre4.gif", "non", "2", " "});
		}

		char[] repeat3 = new char[] {'L', 'E'};
		for(int i=0;i<repeat3.length;i++)
		{
			this.ptsImages.put(repeat3[i] + "1", new String[] {"10", "pEtoile1.gif", "oui", "1", "N"});
			this.ptsImages.put(repeat3[i] + "2", new String[] {"5", "pEtoile2.gif", "oui", "1", "E" });
			this.ptsImages.put(repeat3[i] + "3", new String[] {"10", "pEtoile3.gif", "oui", "1", "S"});
			this.ptsImages.put(repeat3[i] + "4", new String[] {"5", "pEtoile4.gif", "oui", "1", "O" });
		}
	}

	public Map<String, String[]> getPtsImages()
	{
		return this.ptsImages;
	}

	public String[][] grille(int level){
		String rep = "niveaux/niveau";

		try{
			Scanner sc = new Scanner ( new File(rep+String.format("%02d", level)+".txt") );
			int lig = -1;
			int cpt = -1;
			int col = 0;
			String line = "";

			while (!(line = sc.nextLine()).isEmpty())
			{
				lig++;
				col = line.length();
			}

			char[][] tab = new char[lig][col];

			sc = new Scanner( new File(rep+String.format("%02d", level)+".txt"));
			while(!(line = sc.nextLine()).isEmpty())
			{
				if(cpt > 0) { tab[cpt] = line.toCharArray(); }
				cpt++;
			}
			sc.close();

			int[][]    point    = new int[lig/2][col/6]   ;
			String[][] tab2     = new String[lig/2][col/6];
			String[][] tabCases = new String[lig/2][col/6];

			for(int i=1;i<lig;i+=2)
			{
				for(int j=2;j<col;j+=6)
				{
					tabCases[i/2][j/6] = tab[i][j]+""+tab[i][j+1];

					if(ptsImages.containsKey(tab[i][j]+""+tab[i][j+1]))
					{
						point[i/2][j/6] =  Integer.valueOf(ptsImages.get(tab[i][j]+""+tab[i][j+1])[0]);
					}

				}
			}

			return tabCases;
		}
		catch (FileNotFoundException e){
			return new String[3][3];
		}

	}

	public static void main(String[] arg)
	{
		/*-----------------*/
		/* Données         */
		/*-----------------*/
		System.out.println("Choissisez votre theme ( 1 : Normal , 2 : Noel )");
		int         theme = Clavier.lire_int();
		Decomposeur dec;
		String      ligne;
		int         cpt = 1;
		int         cptImg = 1;

		affichageNiveauHtml obj = new affichageNiveauHtml();
		obj.initPtsImages();

		// Image : obj.getPtsImages().get("+2")[1]
		// Tableau de tuiles: obj.grille(1)[0][0]
		String tuile1;
		String imageTuile1;

		try
		{

			String rep = "./Site/";
			Scanner scFic = new Scanner ( new FileReader( rep + "index.html"));
			PrintWriter pw = new PrintWriter (rep + "temporaire.html");



			while ( scFic.hasNextLine() )
			{
				ligne= scFic.nextLine();
				pw.println(ligne);
				if(cpt == 42)
				{
					while(cptImg <= 40)
					{
						pw.println("								<div class=\"col-12 col-sm-6 col-lg-4 niveau  wow fadeInUp\" data-wow-delay=\"700ms\">");
						pw.println("									<p class=\"nam_pos\">Niveau " + cptImg+ " </p>");
						if( theme == 1 ) {pw.println("									<div class='tableauNormal'>");}
						else if ( theme == 2 ) {pw.println("									<div class='tableauNoel'>");}
						pw.println("										<table style='margin: 0 auto;'>");

						for(int i = 0;i<3;i++)
						{
							pw.println("											<tr>");
							for(int y = 0;y<3;y++)
							{

								tuile1 = obj.grille(cptImg)[i][y];

								if(tuile1.equals("  ") || tuile1.trim().isEmpty())
								{
									imageTuile1 = "vide80.gif";
								}
								else
								{
									if(obj.getPtsImages().containsKey(tuile1))
									{
										imageTuile1 = obj.getPtsImages().get(tuile1)[1];
									}
									else
									{
										break;
									}
								}

								pw.println("												<td>");
								if(theme == 1)
								{
									pw.println("													<img src=\"../images/Normal/" + imageTuile1 + " \"></td>");

								}
								else if(theme == 2)
								{
									pw.println("													<img src=\"../images/Noel/" + imageTuile1 + " \"></td>");

								}
							}
							pw.println("											</tr>");

						}
						pw.println("										</table>");
						pw.println("									</div>");
						pw.println("								</div>");
						cptImg++;
					}
					cptImg = 1;


				}



				cpt++;
			}

			pw.close();
			scFic = new Scanner     ( new FileReader( rep + "temporaire.html"));
			pw    = new PrintWriter (rep + "index.html");

			while ( scFic.hasNextLine() )
			{
				ligne= scFic.nextLine();
				pw.println(ligne);
				cpt++;
			}

			pw.close();


		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
